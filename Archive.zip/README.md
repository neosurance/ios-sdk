# NeosuranceSDK

[![CI Status](http://img.shields.io/travis/Tonino Mendicino/NeosuranceSDK.svg?style=flat)](https://travis-ci.org/Tonino Mendicino/NeosuranceSDK)
[![Version](https://img.shields.io/cocoapods/v/NeosuranceSDK.svg?style=flat)](http://cocoapods.org/pods/NeosuranceSDK)
[![License](https://img.shields.io/cocoapods/l/NeosuranceSDK.svg?style=flat)](http://cocoapods.org/pods/NeosuranceSDK)
[![Platform](https://img.shields.io/cocoapods/p/NeosuranceSDK.svg?style=flat)](http://cocoapods.org/pods/NeosuranceSDK)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

NeosuranceSDK is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'NeosuranceSDK'
```

## Author

Tonino Mendicino, tonino@clickntap.com

## License

NeosuranceSDK is available under the MIT license. See the LICENSE file for more info.
