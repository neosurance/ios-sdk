#import <Foundation/Foundation.h>

@interface NeosuranceSDK : NSObject

-(void)hello;

@end
