#import "NeosuranceSDK.h"

@implementation NeosuranceSDK

-(void)hello {
    NSLog(@"hello...");
}

@end
