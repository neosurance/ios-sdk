//
//  NSRViewController.m
//  NeosuranceSDK
//
//  Created by Tonino Mendicino on 12/01/2017.
//  Copyright (c) 2017 Tonino Mendicino. All rights reserved.
//

#import "NSRViewController.h"

@interface NSRViewController ()

@end

@implementation NSRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
